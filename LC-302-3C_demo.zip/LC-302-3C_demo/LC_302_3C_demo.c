#include <stdio.h>
#include <unistd.h>
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "iot_gpio.h"
#include "iot_uart.h"
#include "hi_io.h"

#define LC_302_3C_UART_RX_PIN   (1)
#define LC_302_3C_UART_TX_PIN   (0)
#define LC_302_3C_UART_IDX      (1)

#define LC_302_3C_UART_BAUD     (19200)
#define LC_302_3C_DATA_LENGHTH  (14)

typedef struct{
    uint16_t Vx;
    uint16_t Vy;
    uint16_t dt;
    uint16_t valid;//判断数据是否可用
    uint8_t version;
    uint16_t Groung_H;
}LC_302_3C_Data;

#define STACK_SIZE 1024

static uint8_t buffer[14];

LC_302_3C_Data Data_Out;

uint8_t LC_302_3C_Init()
{
    //初始化 IO 口
    IoTGpioInit(LC_302_3C_UART_RX_PIN);
    IoTGpioSetFunc(LC_302_3C_UART_RX_PIN,HI_IO_FUNC_GPIO_1_UART1_RXD);

    IoTGpioInit(LC_302_3C_UART_TX_PIN);
    IoTGpioSetFunc(LC_302_3C_UART_TX_PIN,HI_IO_FUNC_GPIO_0_UART1_TXD);

    //初始化串口
    IotUartAttribute g_uart_cfg = {LC_302_3C_UART_BAUD, 8, 1, IOT_UART_PARITY_NONE, 500, 500, 0};
    int ret = IoTUartInit(LC_302_3C_UART_IDX, &g_uart_cfg);
    if (ret != 0) 
    {
        printf("uart init fail\r\n");
        return ret;
    }
    return 0;
}

void LC_302_3C_Get_Data()
{   
    IoTUartRead(LC_302_3C_UART_IDX, buffer ,LC_302_3C_DATA_LENGHTH);

    if(buffer[0] == 0xFE && buffer[1] == 0x0A && buffer[13] == 0x55)
    {
        if(buffer[10] == 0xF5)
        {
            Data_Out.version = buffer[11];
            Data_Out.Vx = ((buffer[3]<<8)|buffer[2]);
            Data_Out.Vy = ((buffer[5]<<8)|buffer[4]);
            Data_Out.dt = ((buffer[7]<<8)|buffer[6]);
            Data_Out.Groung_H = ((buffer[9]<<8)|buffer[8]);
        }
        else
        {
            printf("LC_302_3C_Get_Data failed! the Data is not valid!\n");
        }
    }
    else
    {
        printf("LC_302_3C_Get_Data failed! the buffer is not right!\n");
    }

}


static void* LC_302_3C_Demo_Task()
{
    LC_302_3C_Init();

    while(1)
    {
        LC_302_3C_Get_Data();
        printf("%d,%d,%d\n",
        Data_Out.Vx,Data_Out.Vy,Data_Out.Groung_H,Data_Out.dt,Data_Out.version);

        osDelay(1);
    }
    return NULL;
}

/*
 * 任务入口函数
 * Task Entry Function
 */
static void LC_302_3C_Demo_Entry(void)
{
    osThreadAttr_t attr = {0};

    printf("[LC_302_3C_Demo] LC_302_3C_Demo_Entry()\n");

    attr.name = "LC_302_3C_Demo_Task";
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = STACK_SIZE;      
    attr.priority = osPriorityNormal;  

    if (osThreadNew((osThreadFunc_t)LC_302_3C_Demo_Task, NULL, &attr) == NULL) 
    {
        printf("[LC_302_3C_demo] Falied to create LC_302_3C_Demo_Task!\n");
    }
}

/*
 * 注册模块
 * registration module
 */
APP_FEATURE_INIT(LC_302_3C_Demo_Entry);